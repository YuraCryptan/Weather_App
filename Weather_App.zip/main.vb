' Weather App
Module Module1
Sub Main()
Console.WriteLine("Weather App Initialized")
End Sub
End Module